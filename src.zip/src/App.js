import React from 'react';
import logo from './logo.svg';
import './App.css';
import Testforfiles from './Files/Material-Ui stuff/testforfiles'; 
import ContainerAuto from './Files/Material-Ui stuff/ContainerFixed'; 
import ApplicationBar from './Files/Material-Ui stuff/Appbar'
import FetchLastFm from './Files/Components/fetchLastFm';
import Example from './Files/Components/fetchFail'; 

function App() {
  return (
    <div> 
      <ApplicationBar/>  
    </div>
    
  )
}

export default App;
