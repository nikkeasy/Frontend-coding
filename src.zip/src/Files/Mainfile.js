/*  This is the main file of the EZ Sound Project ~
    Objective is to create a simple UI for the user so that 
    it is possible to search, download and preview 
    sound effects. In addition the user can wish 
    for new ones using a form. 

Name: EZ Sound Project ~
Client id: qWWXRP8Jecepgigr6M1J
Client secret/Api key: RbhjBRUZO37WRXgDSRyY0foFpOA9ENyHFsM4z2m6
Redirect URL: https://freesound.org/home/app_permissions/permission_granted/
*/ 

// randomapi.com API KEY: JZE9-HMWD-EJG5-614Z

// Last.fm API ab29089f40be1f28c5b34468b4afb05f
// shared secret? : a388957535fa3fc5aa0ddfcfc47ae6d1
// registered to: greenchoker  

// Top artist SPAIN 'http://ws.audioscrobbler.com/2.0/?method=geo.gettopartists&country=spain&api_key=ab29089f40be1f28c5b34468b4afb05f&format=json': 
// http://ws.audioscrobbler.com/2.0/?method=geo.gettoptracks&country=finland&limit=5&api_key=ab29089f40be1f28c5b34468b4afb05f&format=json
// For more info: "https://www.last.fm/api/intro"
