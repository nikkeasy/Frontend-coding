import React from 'react'; 
import Button from '@material-ui/core/Button'; 
import ContainerFixed from './ContainerFixed'; 



function Testforfiles () { 
return( 
    <div> 
     
        <Button variant="contained" color="primary"> Paina tästä </Button>
        <p> Testiteksti 
                    katotaan mihin tää menee <br /> 
                  
                    LOREM IPSUM JA SITÄ RATAA
                    LOREM IPSUM JA SITÄ RATAA
                    LOREM IPSUM JA SITÄ RATAA
                    LOREM IPSUM JA SITÄ RATAA
                    LOREM IPSUM JA SITÄ RATAA
                    LOREM IPSUM JA SITÄ RATAA
                    
                </p>
    
    </div>
)

}

export default Testforfiles; 