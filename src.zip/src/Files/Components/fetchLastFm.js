import React, {useEffect, useState}  from 'react'; 
import Card from '@material-ui/core/Card'; 
import { makeStyles } from '@material-ui/core/styles';


const useStyles = makeStyles({
    cardstyle: 
    {
    border: '3px groove red',
    borderRadius: '15px',
    margin: '15px',
    maxWidth: '150px', 
        },

})

function FetchLastFm () {

    const classes = useStyles();

    const [tracks, setTracks ] = useState([]);
    const [artist, setArtist] = useState([]); 
    const [virhe, setVirhe] = useState('Loading da files...');
    const [rank, setRank] = useState([]); 
    
    const fetchUrl = async () => {
        try { 
    
            const response = await fetch('http://ws.audioscrobbler.com/2.0/?method=geo.gettoptracks&country=finland&limit=5&api_key=ab29089f40be1f28c5b34468b4afb05f&format=json');
            const json = await response.json();
             setVirhe ('');
             setTracks(json.tracks.track[0].name);  
            // setArtist(json.tracks.track[0].artist); // Ei toimi.. sain aikaisemmin toimimaan mutta vahingossa poistui tiedosto ja tässä sitä nyt ollaan
            // setArtist(json.tracks.track[0].artist);
             
              
             
           
    
        } catch (error) {
            setVirhe("Error while fetching data :( :( "); 
        }
}
    
    useEffect( () => { fetchUrl() }, [] );
    
    if (virhe.lenght > 0) {
        return( 
                <p> {virhe} </p>
            );
    }
    
        return( 
            <div>
                <Card className= { classes.cardstyle}>
                Track:  { tracks } <br/> 
                Artist: { artist } <br />
                Rank: { rank } 
                </Card>
            </div>
    
    
        )
    
    }
    
    export default FetchLastFm;
    
    //API-KEY aa90ec56063b8a21e8c959047e6b9dd6
    